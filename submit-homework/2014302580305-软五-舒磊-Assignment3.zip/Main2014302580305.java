import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.sql.*;
public class Main2014302580305 {

	public static void main(String[] args) throws IOException {
		//���߳�ʱ��
		long singlestartTime=System.currentTimeMillis();
		// TODO Auto-generated method stub
		Thread2014302580305 single = new Thread2014302580305();
		single.SingleThread();
		long singleendTime=System.currentTimeMillis();
		System.out.println("���߳���ȡʱ��Ϊ��"+(singleendTime-singlestartTime)+"ms");
		
		//���߳�ʱ��
		long multistartTime=System.currentTimeMillis();
		// TODO Auto-generated method stub
		Thread2014302580305 multi = new Thread2014302580305();
		multi.SingleThread();
		long multiendTime=System.currentTimeMillis();
		System.out.println("���߳���ȡʱ��Ϊ��"+(multiendTime-multistartTime)+"ms");
	}

}
