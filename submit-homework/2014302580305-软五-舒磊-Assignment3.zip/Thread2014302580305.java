import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.sql.*;
public class Thread2014302580305 implements Runnable{
	String website = "http://staff.whu.edu.cn/index.jsp?lang=cn";
	LinkedList<String> teachers;
	String str;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
			Crawler2014302580305 one = new Crawler2014302580305();
			try {
				one.Crawler(str);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	//���߳�
	public void SingleThread() throws IOException {
		Crawler2014302580305 one = new Crawler2014302580305();
		teachers = one.Crawler(website);
		//�ٶȵı���Iterator����
		Iterator<String> it = teachers.iterator();  
		while(it.hasNext()) {  
		      one.getInformation(it.next());
		}  
	
	}
	//���߳�
	public void MultiThread() throws IOException {
		//��ȡ��ǰϵͳ��CPU ��Ŀ
		int cpuNums = Runtime.getRuntime().availableProcessors();
        //ExecutorServiceͨ������ϵͳ��Դ��������̳߳ش�С
		ExecutorService executorService =Executors.newFixedThreadPool(cpuNums);
		Crawler2014302580305 one = new Crawler2014302580305();
		teachers = one.Crawler(website);
		//�ٶȵı���Iterator����
		Iterator<String> it = teachers.iterator();  
		while(it.hasNext()) { 
			str = it.next();
			executorService.execute(new Thread()); 
		}
		executorService.shutdown();
	}
}
